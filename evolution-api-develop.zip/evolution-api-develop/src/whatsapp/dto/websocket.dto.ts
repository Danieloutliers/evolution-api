export class WebsocketDto {
  enabled: boolean;
  events?: string[];
}
